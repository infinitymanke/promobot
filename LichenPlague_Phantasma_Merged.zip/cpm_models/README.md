# LichenPlague race visuals

Расовый визуал по умолчанию не использует Customizable Player Models.
Заражённых игроков отмечает прозрачная 16x16 накладка лихена на груди,
которую отображает невидимая marker armor stand.

## Ресурсы накладки

- Item definition: `assets/lichen/items/lichen_chest_overlay.json`
- Item model: `assets/lichen/models/item/lichen_chest_overlay.json`
- Texture: `assets/lichen/textures/entity/lichen_chest.png`

Включи resourcepack и оставь `items.use-item-model: true` в конфиге.
Положение накладки относительно игрока настраивается через
`visuals.chest-overlay-anchor-offset`.

## Legacy CPM

Старые `.cpmmodel` файлы и CPM-провайдер оставлены только для совместимости.
Они не применяются при `models.provider: none` или `auto`; CPM на клиенте для
стандартного armor-stand-визуала не требуется.
